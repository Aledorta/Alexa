const Alexa = require('ask-sdk-core');

const LaunchRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'LaunchRequest';
    },
    handle(handlerInput) {
        return GetFactIntentHandler.handle(handlerInput);
    }
};
const GetFactIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'GetFactIntent'
            || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.YesIntent'   // <-- necessary so the user gets another fact when it says 'yes' when asked if they want another one
            || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NextIntent');// <-- necessary so the gets another fact when it says 'next' (you might want to extend the utterances of this intent with e.g. 'next fact' and similar)
    },
    handle(handlerInput) {
        
        const speechText = getRandomItem(CURIOSIDADES);
        return handlerInput.responseBuilder
            .speak(speechText + getRandomItem(PREGUNTAS))
            .reprompt(getRandomItem(PREGUNTAS)) // <-- necessary to keep the session open so users can request another fact
            .getResponse();
    }
};
const HelpIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && handlerInput.requestEnvelope.request.intent.name === 'AMAZON.HelpIntent';
    },
    handle(handlerInput) {
        const speechText = 'Puedes perdirme una curiosidad. Cómo te puedo ayudar?';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};
const CancelAndStopIntentHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'IntentRequest'
            && (handlerInput.requestEnvelope.request.intent.name === 'AMAZON.CancelIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.StopIntent'
                || handlerInput.requestEnvelope.request.intent.name === 'AMAZON.NoIntent'); // <-- necessary so the session is closed when the user doesn't want more facts
    },
    handle(handlerInput) {
        const speechText = 'Adiós!';
        return handlerInput.responseBuilder
            .speak(speechText)
            .getResponse();
    }
};
const SessionEndedRequestHandler = {
    canHandle(handlerInput) {
        return handlerInput.requestEnvelope.request.type === 'SessionEndedRequest';
    },
    handle(handlerInput) {
        // Any cleanup logic goes here.
        return handlerInput.responseBuilder.getResponse();
    }
};

const ErrorHandler = {
    canHandle() {
        return true;
    },
    handle(handlerInput, error) {
        console.log(`~~~~ Error handled: ${error.message}`);
        const speechText = 'Perdona, hubo un error. Por favor inténtalo otra vez';

        return handlerInput.responseBuilder
            .speak(speechText)
            .reprompt(speechText)
            .getResponse();
    }
};

function getRandomItem(array) { // <--- necessary to obtain a random element of an array
    return array[Math.floor(Math.random()*array.length)]
}

const CURIOSIDADES = [ // replace with your own facts
  'Estos pájaros tienden a ser un poco obsesivos con la limpieza y la higiene, por lo que deben tener a su disposición siempre una pequeña bañera con agua fresca.', 
  'Los canarios odian la soledad hasta tal extremo que pueden llegar a enfermar y morir si pasan demasiado tiempo solos. Es muy importante que si tenemos uno como mascota tenga suficientes estímulos en su jaula para jugar y entretenerse. Asimismo, si se le proporciona un compañero se descubrirá lo cariñosos que son en pareja y lo hermoso que es verlos dormir acurrucados y dándose mimos.',
  'La alimentación de los canarios, a parte del alpiste, está basada en frutas, bayas, semillas y verduras. ',
  'Los canarios son la mascota perfecta para las personas que no disponen de mucho tiempo o que tienen poca movilidad como los ancianos, ya que su atractivo canto es una compañía muy agradable. ',
  'Los canarios usan su canto para marcan el territorio y atraer a su pareja. ',
  'Aunque, antiguamente se creía que las hembras de los pájaros canarios no cantaban, en 2009, un estudio realizado por la investigadora holandesa Tessa Hartog precisó que ciertos niveles de testosterona pueden hacer cantar a las hembras',
  'Estos pájaros suelen dejar de cantar durante la época de muda. Este proceso, que suele comenzar en verano y dura unas ocho semanas, es bastante agotador para el animal, por lo que cantará menos y precisará más tranquilidad. ',
  'La esperanza de vida de los canarios depende del entorno en el que se encuentren, por lo que un ejemplar bien cuidado puede durar entre 8 y 14 años. ',
  'Los canarios eran comúnmente utilizados en las minas de carbón para alertar a los mineros de la presencia de gases nocivos, por lo que si el pájaro moría o cantaba de forma nerviosa los trabajadores debían abandonar inmediatamente el lugar. Afortunadamente, esta práctica se prohibió en 1986. ',
  'Seguramente sueles ver canarios de la misma variedad de colores, pero debes saber que existen más de 30 especies diferentes en relación con su color o tipo de canto.',
  'Si dejan de cantar puede ser por varios motivos: que estén cambiando de plumaje, que estén emparejados, que no tengan luz natural suficiente, que estén enfermos o estresados.',
];

const PREGUNTAS = [ // <-- necessary to provide variations on how to ask if the user wants another fact (and not be repetitive)
  'Quiéres otra?',
  'Quiéres otra curosidad?',
  'Te gustaría saber más?',
  'Quiéres saber la siguiente?',
  'Quiéres la siguiente curiosidad?',
  'Te digo otra?',
  'Te digo la siguiente',
  'Te digo otra curiosidad?',
  'Te digo la siguiente curiosidad?'
];

exports.handler = Alexa.SkillBuilders.custom()
    .addRequestHandlers(
        LaunchRequestHandler,
        GetFactIntentHandler,
        HelpIntentHandler,
        CancelAndStopIntentHandler,
        SessionEndedRequestHandler)
    .addErrorHandlers(
        ErrorHandler)
    .lambda();